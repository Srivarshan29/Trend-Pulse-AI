import React, { useState } from 'react';
import { getGeminiClient, fileToBase64 } from '../lib/gemini';
import { Image as ImageIcon, Video, Activity, FileSearch } from 'lucide-react';
import Markdown from 'react-markdown';

export function MediaStudio() {
  const [prompt, setPrompt] = useState('');
  const [imageSize, setImageSize] = useState('1K');
  const [aspectRatio, setAspectRatio] = useState('16:9');
  const [loading, setLoading] = useState(false);
  const [mediaUrl, setMediaUrl] = useState('');
  const [mediaType, setMediaType] = useState<'image'|'video'|null>(null);
  const [refImage, setRefImage] = useState<File | null>(null);

  const generateImage = async () => {
    setLoading(true);
    try {
      const ai = getGeminiClient();
      const res = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: { parts: [{ text: prompt }] },
        config: { imageConfig: { aspectRatio, imageSize } }
      });
      for (const part of res.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          setMediaUrl(`data:image/png;base64,${part.inlineData.data}`);
          setMediaType('image');
          break;
        }
      }
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    }
    setLoading(false);
  };

  const generateVideo = async () => {
    setLoading(true);
    try {
      const ai = getGeminiClient();
      const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY;
      
      let imagePart = undefined;
      if (refImage) {
        const base64 = await fileToBase64(refImage);
        imagePart = { imageBytes: base64, mimeType: refImage.type };
      }

      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt || undefined,
        image: imagePart,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: aspectRatio === '16:9' || aspectRatio === '9:16' ? aspectRatio : '16:9'
        }
      });

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        operation = await ai.operations.getVideosOperation({ operation });
      }

      const uri = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (uri) {
        const videoRes = await fetch(uri, { headers: { 'x-goog-api-key': apiKey! } });
        const blob = await videoRes.blob();
        setMediaUrl(URL.createObjectURL(blob));
        setMediaType('video');
      }
    } catch (e: any) {
      alert(`Error: ${e.message}`);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Media Studio (Veo 3 & Nano Banana Pro)</h2>
      <div className="grid grid-cols-2 gap-4">
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Prompt..." className="col-span-2 p-3 border rounded-xl" />
        
        <select value={imageSize} onChange={e => setImageSize(e.target.value)} className="p-3 border rounded-xl">
          <option value="1K">1K</option>
          <option value="2K">2K</option>
          <option value="4K">4K</option>
        </select>
        
        <select value={aspectRatio} onChange={e => setAspectRatio(e.target.value)} className="p-3 border rounded-xl">
          <option value="1:1">1:1</option>
          <option value="2:3">2:3</option>
          <option value="3:2">3:2</option>
          <option value="3:4">3:4</option>
          <option value="4:3">4:3</option>
          <option value="9:16">9:16</option>
          <option value="16:9">16:9</option>
          <option value="21:9">21:9</option>
        </select>

        <div className="col-span-2">
          <label className="block text-sm font-medium mb-2">Reference Image (for Video Animation)</label>
          <input type="file" accept="image/*" onChange={e => setRefImage(e.target.files?.[0] || null)} className="p-2 border rounded-xl w-full" />
        </div>
      </div>

      <div className="flex gap-4">
        <button onClick={generateImage} disabled={loading} className="px-6 py-3 bg-indigo-600 text-white rounded-xl flex items-center gap-2">
          {loading ? <Activity className="animate-spin" /> : <ImageIcon />} Gen Image
        </button>
        <button onClick={generateVideo} disabled={loading} className="px-6 py-3 bg-emerald-600 text-white rounded-xl flex items-center gap-2">
          {loading ? <Activity className="animate-spin" /> : <Video />} Gen/Animate Video
        </button>
      </div>

      {mediaUrl && (
        <div className="mt-8">
          {mediaType === 'image' ? (
            <img src={mediaUrl} alt="Generated" className="max-w-full rounded-xl shadow-lg" referrerPolicy="no-referrer" />
          ) : (
            <video src={mediaUrl} controls autoPlay loop className="max-w-full rounded-xl shadow-lg" />
          )}
        </div>
      )}
    </div>
  );
}

export function MediaAnalyzer() {
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const analyze = async () => {
    if (!file) return;
    setLoading(true);
    try {
      const ai = getGeminiClient();
      const base64 = await fileToBase64(file);
      
      let model = 'gemini-3.1-pro-preview';
      if (file.type.startsWith('audio/')) {
        model = 'gemini-3-flash-preview';
      }

      const res = await ai.models.generateContent({
        model,
        contents: {
          parts: [
            { inlineData: { data: base64, mimeType: file.type } },
            { text: file.type.startsWith('audio/') ? 'Transcribe this audio.' : 'Analyze this media in detail.' }
          ]
        }
      });
      setResult(res.text || '');
    } catch (e: any) {
      setResult(`Error: ${e.message}`);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Media Analyzer (Image/Video/Audio)</h2>
      <input type="file" accept="image/*,video/*,audio/*" onChange={e => setFile(e.target.files?.[0] || null)} className="w-full p-3 border rounded-xl" />
      <button onClick={analyze} disabled={loading || !file} className="px-6 py-3 bg-indigo-600 text-white rounded-xl flex items-center gap-2">
        {loading ? <Activity className="animate-spin" /> : <FileSearch />} Analyze Media
      </button>
      {result && <div className="p-6 bg-white rounded-xl shadow-sm markdown-body"><Markdown>{result}</Markdown></div>}
    </div>
  );
}
