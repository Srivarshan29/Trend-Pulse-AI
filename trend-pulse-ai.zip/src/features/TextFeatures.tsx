import React, { useState, useRef } from 'react';
import { getGeminiClient } from '../lib/gemini';
import { Search, Activity, Brain, MapPin, MessageSquare, Mic, Volume2, Square } from 'lucide-react';
import { ThinkingLevel, Modality } from '@google/genai';
import Markdown from 'react-markdown';

export function TrendAnalyzer() {
  const [topic, setTopic] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const analyze = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      const ai = getGeminiClient();
      const searchRes = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `What are the latest trends and news about: ${topic}?`,
        config: { tools: [{ googleSearch: {} }] }
      });
      
      const summaryRes = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-preview',
        contents: `Summarize this trend data into a quick executive brief: ${searchRes.text}`
      });
      
      setResult(summaryRes.text || '');
    } catch (e: any) {
      setResult(`Error: ${e.message}`);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Trend Analyzer (Search + Flash Lite)</h2>
      <div className="flex gap-4">
        <input value={topic} onChange={e => setTopic(e.target.value)} placeholder="Topic..." className="flex-1 p-3 border rounded-xl" />
        <button onClick={analyze} disabled={loading} className="px-6 py-3 bg-indigo-600 text-white rounded-xl flex items-center gap-2">
          {loading ? <Activity className="animate-spin" /> : <Search />} Analyze
        </button>
      </div>
      {result && <div className="p-6 bg-white rounded-xl shadow-sm markdown-body"><Markdown>{result}</Markdown></div>}
    </div>
  );
}

export function DeepThinker() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const think = async () => {
    if (!query) return;
    setLoading(true);
    try {
      const ai = getGeminiClient();
      const res = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: query,
        config: { thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH } }
      });
      setResult(res.text || '');
    } catch (e: any) {
      setResult(`Error: ${e.message}`);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Deep Thinker (Pro + Thinking HIGH)</h2>
      <textarea value={query} onChange={e => setQuery(e.target.value)} placeholder="Ask a complex question..." className="w-full p-3 border rounded-xl h-32" />
      <button onClick={think} disabled={loading} className="px-6 py-3 bg-indigo-600 text-white rounded-xl flex items-center gap-2">
        {loading ? <Activity className="animate-spin" /> : <Brain />} Think Deeply
      </button>
      {result && <div className="p-6 bg-white rounded-xl shadow-sm markdown-body"><Markdown>{result}</Markdown></div>}
    </div>
  );
}

export function LocationIntelligence() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState('');
  const [links, setLinks] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const search = async () => {
    if (!query) return;
    setLoading(true);
    try {
      const ai = getGeminiClient();
      let latLng = undefined;
      try {
        const pos = await new Promise<GeolocationPosition>((res, rej) => navigator.geolocation.getCurrentPosition(res, rej));
        latLng = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
      } catch (e) {
        console.log("Geolocation not available");
      }

      const res = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: query,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: latLng ? { retrievalConfig: { latLng } } : undefined
        }
      });
      
      setResult(res.text || '');
      const chunks = res.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const mapLinks = chunks.filter((c: any) => c.maps?.uri).map((c: any) => c.maps);
      setLinks(mapLinks);
    } catch (e: any) {
      setResult(`Error: ${e.message}`);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Location Intelligence (Maps Grounding)</h2>
      <div className="flex gap-4">
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="e.g., Best coffee shops near me" className="flex-1 p-3 border rounded-xl" />
        <button onClick={search} disabled={loading} className="px-6 py-3 bg-indigo-600 text-white rounded-xl flex items-center gap-2">
          {loading ? <Activity className="animate-spin" /> : <MapPin />} Search Maps
        </button>
      </div>
      {result && <div className="p-6 bg-white rounded-xl shadow-sm markdown-body"><Markdown>{result}</Markdown></div>}
      {links.length > 0 && (
        <div className="mt-4 space-y-2">
          <h3 className="font-semibold">Map Links:</h3>
          <ul className="list-disc pl-5">
            {links.map((link, i) => (
              <li key={i}><a href={link.uri} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline">{link.title || link.uri}</a></li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export function VoiceChat() {
  const [mode, setMode] = useState<'chat'|'tts'|'live'>('chat');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{role: string, text: string}[]>([]);
  const [loading, setLoading] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const sessionRef = useRef<any>(null);

  const handleChat = async () => {
    if (!input) return;
    const newMsgs = [...messages, { role: 'user', text: input }];
    setMessages(newMsgs);
    setInput('');
    setLoading(true);
    try {
      const ai = getGeminiClient();
      const chat = ai.chats.create({ model: 'gemini-3.1-pro-preview' });
      for (const msg of messages) {
        await chat.sendMessage({ message: msg.text });
      }
      const res = await chat.sendMessage({ message: input });
      setMessages([...newMsgs, { role: 'model', text: res.text || '' }]);
    } catch (e: any) {
      console.error(e);
    }
    setLoading(false);
  };

  const handleTTS = async () => {
    if (!input) return;
    setLoading(true);
    try {
      const ai = getGeminiClient();
      const res = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-tts',
        contents: [{ parts: [{ text: input }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } }
        }
      });
      const base64Audio = res.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audio = new Audio(`data:audio/pcm;rate=24000;base64,${base64Audio}`);
        audio.play();
      }
    } catch (e: any) {
      console.error(e);
    }
    setLoading(false);
  };

  const toggleLive = async () => {
    if (isLive) {
      sessionRef.current?.close();
      setIsLive(false);
      return;
    }
    try {
      const ai = getGeminiClient();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      source.connect(processor);
      processor.connect(audioContext.destination);

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } } },
        },
        callbacks: {
          onopen: () => {
            setIsLive(true);
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcm16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                pcm16[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
              }
              const bytes = new Uint8Array(pcm16.buffer);
              let binary = '';
              for (let i = 0; i < bytes.byteLength; i++) {
                binary += String.fromCharCode(bytes[i]);
              }
              const base64Data = btoa(binary);
              sessionPromise.then(session => 
                session.sendRealtimeInput({ media: { data: base64Data, mimeType: 'audio/pcm;rate=16000' } })
              );
            };
          },
          onmessage: (message: any) => {
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              const audio = new Audio(`data:audio/pcm;rate=24000;base64,${base64Audio}`);
              audio.play();
            }
          },
          onclose: () => {
            setIsLive(false);
            processor.disconnect();
            source.disconnect();
            stream.getTracks().forEach(t => t.stop());
          }
        }
      });
      sessionRef.current = await sessionPromise;
    } catch (e) {
      console.error(e);
      setIsLive(false);
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Voice & Chat</h2>
      <div className="flex gap-2 mb-4">
        <button onClick={() => setMode('chat')} className={`px-4 py-2 rounded-lg ${mode === 'chat' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100'}`}>Chatbot</button>
        <button onClick={() => setMode('tts')} className={`px-4 py-2 rounded-lg ${mode === 'tts' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100'}`}>Text-to-Speech</button>
        <button onClick={() => setMode('live')} className={`px-4 py-2 rounded-lg ${mode === 'live' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100'}`}>Live Audio</button>
      </div>
      {mode === 'chat' && (
        <div className="space-y-4">
          <div className="h-64 overflow-y-auto bg-slate-50 p-4 rounded-xl border space-y-4">
            {messages.map((m, i) => (
              <div key={i} className={`p-3 rounded-lg max-w-[80%] ${m.role === 'user' ? 'bg-indigo-600 text-white ml-auto' : 'bg-white border'}`}>
                <Markdown>{m.text}</Markdown>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleChat()} className="flex-1 p-3 border rounded-xl" placeholder="Type a message..." />
            <button onClick={handleChat} disabled={loading} className="px-6 py-3 bg-indigo-600 text-white rounded-xl">
              {loading ? <Activity className="animate-spin" /> : <MessageSquare />}
            </button>
          </div>
        </div>
      )}
      {mode === 'tts' && (
        <div className="space-y-4">
          <textarea value={input} onChange={e => setInput(e.target.value)} className="w-full p-3 border rounded-xl h-32" placeholder="Text to speak..." />
          <button onClick={handleTTS} disabled={loading} className="px-6 py-3 bg-indigo-600 text-white rounded-xl flex items-center gap-2">
            {loading ? <Activity className="animate-spin" /> : <Volume2 />} Generate Speech
          </button>
        </div>
      )}
      {mode === 'live' && (
        <div className="space-y-4 text-center py-12 bg-slate-50 rounded-xl border">
          <button onClick={toggleLive} className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto text-white shadow-lg transition-all ${isLive ? 'bg-red-500 animate-pulse' : 'bg-indigo-600 hover:bg-indigo-700'}`}>
            {isLive ? <Square className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
          </button>
          <p className="text-slate-600 font-medium">{isLive ? 'Listening... Speak now' : 'Click to start live conversation'}</p>
        </div>
      )}
    </div>
  );
}
