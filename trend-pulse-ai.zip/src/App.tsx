import React, { useState } from 'react';
import { TrendingUp, Brain, ImageIcon, FileSearch, MapPin, Mic } from 'lucide-react';
import { ApiKeyPrompt } from './components/ApiKeyPrompt';
import { TrendAnalyzer, DeepThinker, LocationIntelligence, VoiceChat } from './features/TextFeatures';
import { MediaStudio, MediaAnalyzer } from './features/MediaFeatures';

function App() {
  const [activeTab, setActiveTab] = useState('trend');
  const [apiKeyReady, setApiKeyReady] = useState(false);

  const tabs = [
    { id: 'trend', label: 'Trend Analyzer', icon: TrendingUp },
    { id: 'think', label: 'Deep Thinker', icon: Brain },
    { id: 'media', label: 'Media Studio', icon: ImageIcon },
    { id: 'analyze', label: 'Media Analyzer', icon: FileSearch },
    { id: 'location', label: 'Location Intel', icon: MapPin },
    { id: 'voice', label: 'Voice & Chat', icon: Mic },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {!apiKeyReady && <ApiKeyPrompt onKeySelected={() => setApiKeyReady(true)} />}
      
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-slate-200 p-6 flex flex-col h-screen sticky top-0">
        <div className="flex items-center gap-3 mb-8">
          <TrendingUp className="w-8 h-8 text-indigo-600" />
          <h1 className="text-xl font-bold">TrendPulse AI</h1>
        </div>
        
        <nav className="space-y-2 flex-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors ${
                activeTab === tab.id ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          {activeTab === 'trend' && <TrendAnalyzer />}
          {activeTab === 'think' && <DeepThinker />}
          {activeTab === 'media' && <MediaStudio />}
          {activeTab === 'analyze' && <MediaAnalyzer />}
          {activeTab === 'location' && <LocationIntelligence />}
          {activeTab === 'voice' && <VoiceChat />}
        </div>
      </div>
    </div>
  );
}

export default App;
